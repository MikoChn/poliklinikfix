-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 27 Des 2024 pada 17.48
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `poliklinik`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `daftar_poli`
--

CREATE TABLE `daftar_poli` (
  `id` int(11) NOT NULL,
  `id_pasien` int(11) NOT NULL,
  `id_jadwal` int(11) NOT NULL,
  `keluhan` text NOT NULL,
  `no_antrian` int(11) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `daftar_poli`
--

INSERT INTO `daftar_poli` (`id`, `id_pasien`, `id_jadwal`, `keluhan`, `no_antrian`, `tanggal`) VALUES
(1, 1, 1, 'Infeksi Saluran Reproduksi', 1, '2023-12-31 14:21:00'),
(2, 1, 1, 'Gangguan Menstruasi', 2, '2023-12-31 14:20:16'),
(3, 1, 1, 'Konseling Prakonsepsi ', 3, '2023-12-31 14:20:43'),
(4, 5, 3, 'Demam', 1, '2023-12-31 14:17:57'),
(5, 4, 2, 'cabut gigi', 1, '2024-01-02 18:17:31'),
(6, 4, 3, 'Batuk', 2, '2024-01-02 18:20:38'),
(7, 6, 2, 'sakit gigi', 2, '2024-01-04 17:29:33'),
(10, 4, 2, 'Gigi bengkak', 3, '2024-01-05 12:31:33'),
(11, 8, 2, 'Gusi bengkak', 4, '2024-01-05 13:21:37'),
(12, 2, 2, 'Gigi bolong', 5, '2024-01-05 13:22:31'),
(13, 6, 2, 'Cabut gigi', 6, '2024-01-06 17:34:38'),
(14, 7, 10, 'Nyeri Menstruasi', 1, '2024-01-06 17:41:53'),
(15, 7, 1, 'Gangguan Menstruasi', 4, '2024-01-06 17:42:18'),
(16, 7, 9, 'Nyeri Punggung', 1, '2024-01-06 17:43:26'),
(18, 4, 2, 'sakit gusi bengkak', 7, '2024-01-07 07:41:31'),
(19, 9, 2, 'Cabut gigi', 8, '2024-01-07 08:06:39'),
(20, 8, 2, 'cabut gigi', 9, '2024-01-07 14:49:40'),
(21, 4, 5, 'Batuk', 1, '2024-01-07 17:29:46'),
(22, 8, 12, 'Gigi retak', 1, '2024-01-07 17:32:34'),
(24, 13, 5, 'Batuk', 3, '2024-01-08 02:23:48'),
(25, 14, 8, 'Mata merah, gatal, berair, dan terkadang nyeri.', 1, '2024-01-08 02:54:10'),
(26, 15, 4, 'Penglihatan kabur, sulit fokus', 1, '2024-01-08 02:55:42'),
(27, 16, 4, 'Mata merah, iritasi, nanah', 2, '2024-01-08 02:58:00'),
(28, 17, 5, 'flu', 4, '2024-01-08 03:08:59'),
(29, 18, 5, 'flu, batuk, demam', 5, '2024-01-08 03:16:49'),
(30, 1, 7, 'Meriang merindukan kasih sayang', 1, '2024-07-03 05:30:08'),
(31, 19, 2, 'sakit punggung', 10, '2024-12-27 13:35:34'),
(32, 19, 1, 'sakit kepala', 5, '2024-12-27 14:55:18'),
(34, 19, 18, 'sakit gigi', 1, '2024-12-27 15:34:57'),
(35, 20, 19, 'sakit gigi', 1, '2024-12-27 15:56:39'),
(36, 21, 20, 'sakit gigi', 1, '2024-12-27 16:40:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_periksa`
--

CREATE TABLE `detail_periksa` (
  `id` int(11) NOT NULL,
  `id_periksa` int(11) NOT NULL,
  `id_obat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `detail_periksa`
--

INSERT INTO `detail_periksa` (`id`, `id_periksa`, `id_obat`) VALUES
(20, 18, 4),
(21, 19, 2),
(22, 20, 1),
(23, 21, 1),
(24, 22, 1),
(25, 23, 2),
(26, 24, 2),
(27, 25, 2),
(28, 26, 2),
(29, 27, 3),
(30, 28, 3),
(31, 29, 10),
(32, 30, 14),
(33, 31, 15),
(34, 32, 3),
(35, 33, 3),
(36, 34, 9),
(37, 35, 1),
(38, 36, 3),
(39, 37, 1),
(40, 38, 4),
(41, 39, 10);

-- --------------------------------------------------------

--
-- Struktur dari tabel `dokter`
--

CREATE TABLE `dokter` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `no_hp` varchar(50) NOT NULL,
  `id_poli` int(11) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `dokter`
--

INSERT INTO `dokter` (`id`, `nama`, `alamat`, `no_hp`, `id_poli`, `password`) VALUES
(13, 'aryadila', 'jl cemana', '1', 1, '1'),
(17, 'tania', 'tania', '1313123', 1, 'tanaa'),
(18, 'panda', 'jln arwina', '08123123123', 1, '1'),
(19, 'mifta', '1', '1', 3, '1'),
(21, 'malaka', 'malakabarat', '08123123323', 1, '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal_periksa`
--

CREATE TABLE `jadwal_periksa` (
  `id` int(11) NOT NULL,
  `id_dokter` int(11) NOT NULL,
  `hari` enum('Senin','Selasa','Rabu','Kamis','Jumat','Sabtu') NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `jadwal_periksa`
--

INSERT INTO `jadwal_periksa` (`id`, `id_dokter`, `hari`, `jam_mulai`, `jam_selesai`, `status`) VALUES
(1, 7, 'Senin', '22:33:33', '23:33:33', 1),
(2, 3, 'Kamis', '08:05:00', '12:00:00', 0),
(3, 4, 'Kamis', '09:14:58', '14:14:58', 1),
(4, 5, 'Rabu', '09:14:58', '14:14:58', 1),
(5, 4, 'Selasa', '08:16:49', '15:16:49', 0),
(6, 3, 'Rabu', '08:36:22', '11:36:22', 0),
(7, 4, 'Jumat', '13:36:22', '16:36:22', 0),
(8, 5, 'Jumat', '08:37:39', '12:37:39', 0),
(9, 6, 'Jumat', '10:37:39', '15:37:39', 0),
(10, 7, 'Rabu', '12:38:30', '16:38:30', 0),
(11, 3, 'Senin', '03:47:00', '04:46:00', 0),
(12, 3, 'Jumat', '07:51:00', '11:51:00', 0),
(13, 3, 'Sabtu', '07:56:00', '12:56:00', 0),
(14, 3, 'Kamis', '09:57:00', '15:57:00', 0),
(15, 3, 'Kamis', '18:28:00', '20:28:00', 0),
(16, 4, 'Sabtu', '07:09:00', '12:09:00', 0),
(17, 4, 'Rabu', '08:17:00', '13:17:00', 0),
(18, 12, '', '12:00:00', '14:00:00', 0),
(19, 13, '', '12:00:00', '13:30:00', 0),
(20, 21, 'Selasa', '12:00:00', '13:00:00', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `obat`
--

CREATE TABLE `obat` (
  `id` int(11) NOT NULL,
  `nama_obat` varchar(100) NOT NULL,
  `kemasan` varchar(50) NOT NULL,
  `harga` double NOT NULL,
  `stok` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `obat`
--

INSERT INTO `obat` (`id`, `nama_obat`, `kemasan`, `harga`, `stok`) VALUES
(1, 'Paramex', 'Strip', 5000, 4),
(2, 'Bisolvon Extra Sirup', 'Botol', 20000, 4),
(3, 'Konidin OBH', 'Sachet', 3000, 3),
(4, 'Paracetamol', 'Strip', 15000, 2),
(8, 'Ibuprofen', 'Strip', 5000, 1),
(9, 'Obat kumur antiseptik', 'Botol', 15000, 5),
(10, 'Aspirin', 'Strip', 8000, 9),
(11, 'Naproxen', 'Strip', 10000, 11),
(12, 'Prednisone', 'Strip', 20000, 14),
(14, 'Tobramisin', 'Botol', 20000, 5),
(15, 'Timolol', 'Botol', 8000, 5);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pasien`
--

CREATE TABLE `pasien` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `no_ktp` varchar(255) NOT NULL,
  `no_hp` varchar(50) NOT NULL,
  `no_rm` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pasien`
--

INSERT INTO `pasien` (`id`, `nama`, `alamat`, `no_ktp`, `no_hp`, `no_rm`) VALUES
(20, 'pandu', 'pan', '1', '1', '202412-1'),
(21, 'malik', 'jalan sadewa', '08123123131', '08123123123', '202412-2');

-- --------------------------------------------------------

--
-- Struktur dari tabel `periksa`
--

CREATE TABLE `periksa` (
  `id` int(11) NOT NULL,
  `id_daftar_poli` int(11) NOT NULL,
  `tgl_periksa` datetime NOT NULL,
  `catatan` text NOT NULL,
  `biaya_periksa` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `periksa`
--

INSERT INTO `periksa` (`id`, `id_daftar_poli`, `tgl_periksa`, `catatan`, `biaya_periksa`) VALUES
(18, 4, '2024-01-04 21:12:22', 'minum obat teratur', 165000),
(19, 7, '2024-01-05 13:07:09', 'minum obat teratur ', 170000),
(20, 10, '2024-01-05 14:24:26', 'minum obat teratur', 155000),
(21, 11, '2024-01-05 14:43:42', 'Obat teratur', 155000),
(22, 12, '2024-01-05 14:45:16', 'obat teratur', 155000),
(23, 19, '2024-01-07 15:11:40', 'kompres', 170000),
(24, 18, '2024-01-07 15:12:36', 'minum obat', 170000),
(25, 20, '2024-01-07 15:50:22', 'minum obat teratur', 170000),
(26, 10, '2024-01-07 16:41:32', 'minum obat teratur', 170000),
(27, 21, '2024-01-07 19:16:12', 'minum obat teratur', 153000),
(28, 24, '2024-01-08 03:25:23', 'minum obat teratur', 153000),
(29, 22, '2024-01-08 03:48:40', 'jangan makan keras', 158000),
(30, 26, '2024-01-08 03:59:07', 'Obat tetes dipakai teratur', 170000),
(31, 25, '2024-01-08 03:59:52', 'Obat tetes dipakai teratur', 158000),
(32, 28, '2024-01-08 04:10:41', 'minum obat teratur', 153000),
(33, 29, '2024-01-08 04:18:35', 'minum obat teratur', 153000),
(34, 30, '2024-07-03 07:31:15', 'perlu coli 2x sehari', 165000),
(35, 31, '2024-12-27 14:37:09', '', 155000),
(36, 32, '2024-12-27 15:56:13', 'sakit kepala', 153000),
(37, 35, '2024-12-27 16:57:02', 'harus sering tidur', 155000),
(38, 36, '2024-12-27 17:40:36', 'sering istirahat', 165000),
(39, 36, '2024-12-27 17:41:08', '', 158000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `poli`
--

CREATE TABLE `poli` (
  `id` int(11) NOT NULL,
  `nama_poli` varchar(25) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `poli`
--

INSERT INTO `poli` (`id`, `nama_poli`, `keterangan`) VALUES
(1, 'Poli Gigi', 'Spesialis gigi menangani perawatan gigi, mulut, dan rongga mulut. Pelayanan meliputi pembersihan gigi, penambalan, pencabutan gigi, dan perawatan ortodonti.'),
(3, 'Poli Anak', 'Disediakan untuk perawatan dan konsultasi kesehatan anak-anak. Dokter anak atau pediatri memberikan imunisasi, pemeriksaan tumbuh kembang, dan penanganan penyakit anak.'),
(4, 'Poli Mata', 'Spesialis mata (oftalmolog) menangani pemeriksaan mata dan perawatan berbagai kondisi mata. Pemeriksaan mata, pengukuran kacamata, dan penanganan masalah mata seperti infeksi atau penyakit mata.'),
(5, 'Poli Kandungan', 'Menyediakan perawatan untuk perempuan terkait kehamilan, persalinan, dan masalah reproduksi. Pemeriksaan kehamilan, persalinan, dan perawatan ginekologi umum.'),
(6, 'Poli Syaraf', 'Spesialis syaraf atau neurolog merawat gangguan saraf. Pemeriksaan dan pengelolaan kondisi neurologis seperti migrain, stroke, atau epilepsi.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `usertable`
--

CREATE TABLE `usertable` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `usertable`
--

INSERT INTO `usertable` (`id`, `nama`, `username`, `password`) VALUES
(7, 'martina', '1', '$2y$10$TUahf4zO7hU8i3xon.LyOenDwDKrd/yoH0gFSdGxeyRsamaoZGGIy');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `daftar_poli`
--
ALTER TABLE `daftar_poli`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pasien_daftar_poli` (`id_pasien`),
  ADD KEY `fk_jadwal_periksa_daftar_poli` (`id_jadwal`);

--
-- Indeks untuk tabel `detail_periksa`
--
ALTER TABLE `detail_periksa`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_detail_periksa_obat` (`id_obat`),
  ADD KEY `fk_periksa_detail_periksa` (`id_periksa`);

--
-- Indeks untuk tabel `dokter`
--
ALTER TABLE `dokter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_dokter_poli` (`id_poli`);

--
-- Indeks untuk tabel `jadwal_periksa`
--
ALTER TABLE `jadwal_periksa`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_jadwal_periksa_dokter` (`id_dokter`);

--
-- Indeks untuk tabel `obat`
--
ALTER TABLE `obat`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `periksa`
--
ALTER TABLE `periksa`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_daftar_poli_periksa` (`id_daftar_poli`);

--
-- Indeks untuk tabel `poli`
--
ALTER TABLE `poli`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `daftar_poli`
--
ALTER TABLE `daftar_poli`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT untuk tabel `detail_periksa`
--
ALTER TABLE `detail_periksa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT untuk tabel `dokter`
--
ALTER TABLE `dokter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT untuk tabel `jadwal_periksa`
--
ALTER TABLE `jadwal_periksa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `obat`
--
ALTER TABLE `obat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `pasien`
--
ALTER TABLE `pasien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT untuk tabel `periksa`
--
ALTER TABLE `periksa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT untuk tabel `poli`
--
ALTER TABLE `poli`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `usertable`
--
ALTER TABLE `usertable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `daftar_poli`
--
ALTER TABLE `daftar_poli`
  ADD CONSTRAINT `fk_jadwal_periksa_daftar_poli` FOREIGN KEY (`id_jadwal`) REFERENCES `jadwal_periksa` (`id`),
  ADD CONSTRAINT `fk_pasien_daftar_poli` FOREIGN KEY (`id_pasien`) REFERENCES `pasien` (`id`);

--
-- Ketidakleluasaan untuk tabel `detail_periksa`
--
ALTER TABLE `detail_periksa`
  ADD CONSTRAINT `fk_detail_periksa_obat` FOREIGN KEY (`id_obat`) REFERENCES `obat` (`id`),
  ADD CONSTRAINT `fk_periksa_detail_periksa` FOREIGN KEY (`id_periksa`) REFERENCES `periksa` (`id`);

--
-- Ketidakleluasaan untuk tabel `dokter`
--
ALTER TABLE `dokter`
  ADD CONSTRAINT `fk_dokter_poli` FOREIGN KEY (`id_poli`) REFERENCES `poli` (`id`);

--
-- Ketidakleluasaan untuk tabel `jadwal_periksa`
--
ALTER TABLE `jadwal_periksa`
  ADD CONSTRAINT `fk_jadwal_periksa_dokter` FOREIGN KEY (`id_dokter`) REFERENCES `dokter` (`id`);

--
-- Ketidakleluasaan untuk tabel `periksa`
--
ALTER TABLE `periksa`
  ADD CONSTRAINT `fk_daftar_poli_periksa` FOREIGN KEY (`id_daftar_poli`) REFERENCES `daftar_poli` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
