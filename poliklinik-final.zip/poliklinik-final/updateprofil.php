<?php
// Memulai session
session_start();
include_once("koneksi.php");

// Pastikan dokter sudah login dan id_dokter ada di session
if (!isset($_SESSION['id_dokter'])) {
    die("Harap login terlebih dahulu.");
}

$id_dokter = $_SESSION['id_dokter']; // Mendapatkan id_dokter dari session

// Ambil data dokter berdasarkan id
$query = "SELECT * FROM dokter WHERE id = ?";
$stmt = mysqli_prepare($mysqli, $query);
mysqli_stmt_bind_param($stmt, "i", $id_dokter); // "i" untuk integer
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Pastikan query berhasil dan data ditemukan
if ($result) {
    $dokter = mysqli_fetch_assoc($result);
    if (!$dokter) {
        die("Dokter tidak ditemukan.");
    }
} else {
    die("Query gagal: " . mysqli_error($mysqli));
}

// Proses jika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $nama = mysqli_real_escape_string($mysqli, $_POST['nama']);
    $alamat = mysqli_real_escape_string($mysqli, $_POST['alamat']);
    $no_hp = mysqli_real_escape_string($mysqli, $_POST['no_hp']);

    // Validasi input
    if (empty($nama) || empty($alamat) || empty($no_hp)) {
        echo "<script>alert('Semua kolom harus diisi!');</script>";
    } else {
        // Query untuk memperbarui data dokter
        $updateQuery = "UPDATE dokter SET nama=?, alamat=?, no_hp=? WHERE id=?";
        $updateStmt = mysqli_prepare($mysqli, $updateQuery);
        mysqli_stmt_bind_param($updateStmt, "sssi", $nama, $alamat, $no_hp, $id_dokter);

        // Eksekusi query update
        if (mysqli_stmt_execute($updateStmt)) {
            echo "<script>alert('Profil berhasil diperbarui!'); window.location.href='berandaDokter.php';</script>";
        } else {
            echo "<script>alert('Terjadi kesalahan: " . mysqli_error($mysqli) . "');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Profil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Ubah Profil</h2>
    <form method="POST">
        <div class="mb-3">
            <label for="nama" class="form-label">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?php echo htmlspecialchars($dokter['nama']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="alamat" class="form-label">Alamat</label>
            <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo htmlspecialchars($dokter['alamat']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="no_hp" class="form-label">No. HP</label>
            <input type="text" class="form-control" id="no_hp" name="no_hp" value="<?php echo htmlspecialchars($dokter['no_hp']); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="berandaDokter.php" class="btn btn-secondary">Batal</a>
    </form>
</div>
</body>
</html>
