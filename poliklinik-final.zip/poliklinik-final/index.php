<?php
if (!isset($_SESSION)) {
    session_start();
}

include_once("koneksi.php");
?>

<!doctype html>
<html lang="id">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Poliklinik</title>
    <link rel="icon" href="img/favicon.png" type="image/x-icon" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light pt-2 ps-4 pe-3 shadow-sm fixed-top">
    <div class="container">
        <a class="navbar-brand" href="index.php">Poliklinik</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <?php
                if (isset($_SESSION['username'])) {
                ?>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?page=obat">Obat</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?page=dokter">Dokter</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?page=poli">Poli</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?page=pasien">Pasien</a>
                    </li>
                <?php
                }
                ?>
            </ul>
            <ul class="navbar-nav ms-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Daftar</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="index.php?page=daftarAdmin">Daftar Admin</a></li>
                        <li><a class="dropdown-item" href="index.php?page=daftarDokter">Daftar Dokter</a></li>
                    </ul>
                </li>
                <?php
                if (isset($_SESSION['username'])) {
                ?>
                    <li class="nav-item">
                        <a class="nav-link" href="logoutUser.php">Logout (<?php echo $_SESSION['username'] ?>)</a>
                    </li>
                <?php
                } else {
                ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Login</a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="index.php?page=loginUser">Admin</a></li>
                            <li><a class="dropdown-item" href="index.php?page=loginDokter">Dokter</a></li>
                        </ul>
                    </li>
                <?php
                }
                ?>
            </ul>
        </div>
    </div>
</nav>


    <main role="main" class="container-fluid">
        <?php
            if (isset($_GET['page'])) {
                include($_GET['page'] . ".php");
            } else {
                if (isset($_SESSION['username'])) {
                    echo '<section class="slider">
                    <div class="hero-slider">
                        <div class="single-slider">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-7 pt-5">
                                        <div class="text">
                                            <h1>Selamat Datang Admin</h1>
                                            <h2>Di Poliklinik Udinus</h2>
                                            <h2>Hello, '. $_SESSION['username'] .'</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>';
                } else {
                    echo '
                    <section class="slider">
                        <div class="hero-slider">
                            <div class="single-slider">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-lg-7">
                                            <div class="text">
                                                <h1>Selamat Datang di Sistem Informasi Poliklinik</h1>
                                                <h2>Sistem Informasi Poliklinik kami memungkinkan Anda untuk mengelola data dokter, pasien, obat, dan pemeriksaan dengan efisien dan mudah.</h2>
                                                <p>Gunakan navigasi di atas untuk mengakses fitur yang tersedia. Jika Anda belum memiliki akun, silakan registrasi terlebih dahulu.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <section class="schedule">
                        <div class="container">
                            <div class="schedule-inner">
                                <div class="row d-flex align-item-center justify-content-center">
                                    <div class="col-lg-4 col-md-6 col-12">
                                        <div class="single-schedule first">
                                            <div class="inner">
                                                <div class="icon">
                                                    <i class="fa fa-ambulance"></i>
                                                </div>
                                                <div class="single-content">
                                                    <h4>Login Sebagai Pasien</h4>
                                                    <p>Silahkan Mendaftar terlebih dahulu</p>
                                                    <a href="index.php?page=daftarPasien" class="btn">MASUK<i class="fa fa-long-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-12">
                                        <div class="single-schedule middle">
                                            <div class="inner">
                                                <div class="icon">
                                                    <i class="icofont-prescription"></i>
                                                </div>
                                                <div class="single-content">
                                                    <h4>Login Sebagai Dokter</h4>
                                                    <p>silahkan Login terlebih dahulu</p>
                                                    <a href="index.php?page=loginDokter" class="btn">MASUK<i class="fa fa-long-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>';
                }
            }
        ?>
    </main>

    <footer class="bg-light py-4 mt-5">
        <div class="container text-center">
            <p>© Copyright 2024 | All Rights Reserved by <a href="https://instagram.com/agunggpndw" target="_blank">Agung Pandu Widjanarko</a></p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>
