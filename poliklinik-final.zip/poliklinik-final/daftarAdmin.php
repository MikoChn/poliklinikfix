<?php
if (!isset($_SESSION)) {
    session_start();
}
require 'koneksi.php'; // Pastikan koneksi database

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $query = "INSERT INTO usertable (nama, username, password) VALUES ('$nama', '$username', '$password')";

    if ($mysqli->query($query)) {
        $success = "Pendaftaran berhasil.";
    } else {
        $error = "Terjadi kesalahan: " . $mysqli->error;
    }
}
?>

<div class="container d-flex justify-content-center align-items-center min-vh-100">
    <div class="row border rounded-5 p-3 bg-white shadow">
        <div class="col-md-10 right-box align-items-center">
            <div class="row align-items-center">
                <div class="header-text mb-4">
                    <h2>Daftar Admin</h2>
                </div>
                <form method="POST" action="">
                    <?php
                    if (isset($success)) {
                        echo '<div class="alert alert-success">' . $success . '</div>';
                    } elseif (isset($error)) {
                        echo '<div class="alert alert-danger">' . $error . '</div>';
                    }
                    ?>
                    <div class="form-group mb-3">
                        <label for="nama">Nama</label>
                        <input type="text" name="nama" class="form-control" placeholder="Masukkan nama Anda" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="username">Username</label>
                        <input type="text" name="username" class="form-control" placeholder="Masukkan username Anda" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="password">Password</label>
                        <input type="password" name="password" class="form-control" placeholder="Masukkan password Anda" required>
                    </div>
                    <div class="form-group mb-3">
                        <button class="btn btn-primary w-100" type="submit">Daftar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
