<?php
if (!isset($_SESSION)) {
    session_start();
}
include_once("koneksi.php");
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Poliklinik</title>
    <link rel="icon" href="img/favicon.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <style>
        /* Sidebar styling */
        .sidebar {
            width: 250px;
            min-height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            color: white;
            padding: 20px;
            z-index: 1000;
        }

        .sidebar h4 {
            text-align: center;
        }

        .sidebar a {
            text-decoration: none;
            color: white;
            margin-bottom: 10px;
            display: block;
        }

        .sidebar a:hover {
            color: #ffc107;
        }

        .content {
            margin-left: 250px; /* Match the sidebar width */
            padding: 20px;
            width: calc(100% - 250px); /* Adjust width for responsive design */
            position: relative;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
            }

            .content {
                margin-left: 200px;
                width: calc(100% - 200px);
            }
        }

        @media (max-width: 576px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .content {
                margin-left: 0;
                width: 100%;
            }
        }
    </style>
</head>
<body>
<div class="d-flex">
    <!-- Sidebar -->
    <nav class="sidebar">
        <h4>Poliklinik</h4>
        <ul class="nav flex-column mt-4">
            <li class="nav-item">
                <a href="berandaDokter.php">Home</a>
            </li>
            <?php if (isset($_SESSION['nama'])) { ?>
                <li class="nav-item">
                    <a href="berandaDokter.php?page=periksa">Periksa</a>
                </li>
                <li class="nav-item">
                    <a href="berandaDokter.php?page=riwayatPasien">Riwayat Pasien</a>
                </li>
                <li class="nav-item">
                    <a href="berandaDokter.php?page=jadwalDokter">Jadwal Dokter</a>
                </li>
                <li class="nav-item">
                    <a href="ubahprofil.php?page=jadwalDokter">Ubah Profile Dokter</a>
                </li>
            <?php } ?>
        </ul>
        <div class="mt-auto">
            <?php if (isset($_SESSION['nama'])) { ?>
                <a class="btn btn-danger w-100" href="logoutDokter.php">Logout (<?php echo $_SESSION['nama']; ?>)</a>
            <?php } else { ?>
                <div class="dropdown">
                    <button class="btn btn-primary dropdown-toggle w-100" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Login
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="index.php?page=loginUser">Admin</a></li>
                        <li><a class="dropdown-item" href="index.php?page=loginDokter">Dokter</a></li>
                    </ul>
                </div>
            <?php } ?>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="content">
        <main role="main" class="container-fluid mt-4">
            <?php
            if (isset($_GET['page'])) {
                include($_GET['page'] . ".php");
            } else {
                if (isset($_SESSION['nama'])) {
                    echo '<section class="slider">
                        <div class="hero-slider">
                            <div class="single-slider">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-lg-7 pt-5">
                                            <div class="text">
                                                <h1>Selamat Datang di poliklinik </h1>
                                                <h2>Hello, ' . $_SESSION['nama'] . '</h2>
                                                <p>Silakan pilih menu di sidebar.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>';
                } else {
                    echo '
                        <section class="about_section pt-3">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="img-box">
                                            <img src="img/about1.png" alt="">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="detail-box">
                                            <div class="heading_container">
                                                <h3>Selamat datang di Poliklinik!</h3>
                                            </div>
                                            <p class="aboutpoli" style="font-size: 16px;">
                                                Silakan pilih menu di sidebar untuk mengelola jadwal, memeriksa pasien, dan melihat riwayat pemeriksaan.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    ';
                }
            }
            ?>
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>
