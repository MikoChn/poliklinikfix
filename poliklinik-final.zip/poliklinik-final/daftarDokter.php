<?php
if (!isset($_SESSION)) {
    session_start();
}

// Memeriksa apakah request yang diterima adalah POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Mengambil data dari form pendaftaran
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $no_hp = $_POST['no_hp'];
    $id_poli = $_POST['id_poli'];
    $password = $_POST['password'];

    // Validasi sederhana
    if (empty($nama) || empty($alamat) || empty($no_hp) || empty($id_poli) || empty($password)) {
        $error = "Semua field harus diisi.";
    } else {
        // Menghindari SQL Injection
        $nama = $mysqli->real_escape_string($nama);
        $alamat = $mysqli->real_escape_string($alamat);
        $no_hp = $mysqli->real_escape_string($no_hp);
        $id_poli = $mysqli->real_escape_string($id_poli);
        $password = $mysqli->real_escape_string($password);

        // Query untuk menyimpan data dokter baru
        $query = "INSERT INTO dokter (nama, alamat, no_hp, id_poli, password) VALUES ('$nama', '$alamat', '$no_hp', '$id_poli', '$password')";

        if ($mysqli->query($query)) {
            $success = "Pendaftaran berhasil. Silakan login.";
        } else {
            $error = "Terjadi kesalahan: " . $mysqli->error;
        }
    }
}
?>

<div class="container d-flex justify-content-center align-items-center min-vh-100">
    <div class="row border rounded-5 p-3 bg-white shadow">
        <!-------------------- ------ Right Box ---------------------------->
        <div class="col-md-10 right-box align-items-center">
            <div class="row align-items-center">
                <div class="header-text mb-4">
                    <h2>Daftar Dokter</h2>
                    <p>Silakan isi form di bawah untuk mendaftar.</p>
                </div>
                <form method="POST" action="index.php?page=daftarDokter">
                    <?php
                    if (isset($error)) {
                        echo '<div class="alert alert-danger">' . $error . '</div>';
                    }
                    if (isset($success)) {
                        echo '<div class="alert alert-success">' . $success . '</div>';
                    }
                    ?>
                    <div class="form-group mb-3">
                        <label for="nama">Nama</label>
                        <input type="text" name="nama" class="form-control form-control-lg bg-light fs-6" placeholder="Masukkan nama Anda" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="alamat">Alamat</label>
                        <input type="text" name="alamat" class="form-control form-control-lg bg-light fs-6" placeholder="Masukkan alamat Anda" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="no_hp">No HP</label>
                        <input type="text" name="no_hp" class="form-control form-control-lg bg-light fs-6" placeholder="Masukkan nomor HP Anda" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="id_poli">ID Poli</label>
                        <input type="number" name="id_poli" class="form-control form-control-lg bg-light fs-6" placeholder="Masukkan ID poli Anda" required>
                    </div>
                    <div class="form-group mb-5">
                        <label for="password">Password</label>
                        <input type="password" name="password" class="form-control form-control-lg bg-light fs-6" placeholder="Masukkan password Anda" required>
                    </div>
                    <div class="form-group mb-3">
                        <button class="btn btn-lg btn-primary w-100 fs-6" type="submit">Daftar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
