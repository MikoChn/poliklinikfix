# poliklinikudinus
Aplikasi Website Poliklinik Udinus, Jadwal Temu Pasien dan Dokter

Pastikan mengintall Xampp dengan versi PHP 7 Keatas
Buat database dengan nama "poli" atau sesuaikan dengan koneksi.php
Impor databasenya

Langkah awal login sebagai admin dengan user : admin, password : admin123
Untuk user dokter bisa cek di database untuk usernamenya adalah nama lengkap

Silahkan mencoba fitur yang ada, CRUD data mulai dari pembuatan pasien, obat, dokter dan poli

Bisa akses juga link hostingnya di [https://poliklinikudinus.000webhostapp.com](http://poliklinikudinus.000webhostapp.com/)
Cuman belum saya perbaiki lagi di file systemnya harus di sesuaikan, kadang error. Disarankan menggunakan local server (XAMPP/MAMP)

- Rio Arlianda (A11.2020.12796)
