<?php
// Mulai session jika belum dimulai
if (!isset($_SESSION)) {
    session_start();
}

// Sambungkan ke database
include('koneksi.php');

// Pastikan hanya akses dari tombol cetak yang diizinkan
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

// Ambil ID dari parameter URL
$id_periksa = $_GET['id'];

// Query untuk mendapatkan data periksa berdasarkan ID
$query = "SELECT daftar_poli.*, pasien.nama AS nama, jadwal_periksa.hari, periksa.tgl_periksa, periksa.catatan, periksa.biaya_periksa, obat.nama_obat AS nama_obat
          FROM daftar_poli
          JOIN jadwal_periksa ON daftar_poli.id_jadwal = jadwal_periksa.id 
          JOIN pasien ON daftar_poli.id_pasien = pasien.id
          LEFT JOIN periksa ON daftar_poli.id = periksa.id_daftar_poli
          LEFT JOIN detail_periksa ON periksa.id = detail_periksa.id_periksa
          LEFT JOIN obat ON detail_periksa.id_obat = obat.id
          WHERE daftar_poli.id = '$id_periksa'";

$result = mysqli_query($mysqli, $query);

// Memastikan ada hasil dari query
if (mysqli_num_rows($result) > 0) {
    $data = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice Periksa Pasien</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        .container {
            width: 80%;
            margin: auto;
            padding: 20px;
            background: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .header img {
            width: 100px;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        table th {
            background-color: #f4f4f4;
            color: #333;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 16px;
            color: #555;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <img src="img/favicon.png" alt="Logo">
            <h1>Poliklinik</h1>
            <p>Invoice Pemeriksaan Pasien</p>
        </div>
        <h2>Detail Pemeriksaan</h2>
        <table>
            <tr>
                <th>Tanggal Periksa</th>
                <td><?php echo $data['tgl_periksa']; ?></td>
            </tr>
            <tr>
                <th>Nama Pasien</th>
                <td><?php echo $data['nama']; ?></td>
            </tr>
            <tr>
                <th>Nomor Antrian</th>
                <td><?php echo $data['no_antrian']; ?></td>
            </tr>
            <tr>
                <th>Keluhan</th>
                <td><?php echo $data['keluhan']; ?></td>
            </tr>
            <tr>
                <th>Catatan</th>
                <td><?php echo $data['catatan']; ?></td>
            </tr>
            <tr>
                <th>Harga Obat</th>
                <td><?php echo $data['biaya_periksa'] - 150000; ?></td>
            </tr>
            <tr>
                <th>Biaya Dokter</th>
                <td>150000</td>
            </tr>
            <tr>
                <th>Total Biaya</th>
                <td><?php echo $data['biaya_periksa']; ?></td>
            </tr>
            <tr>
                <th>Nama Obat</th>
                <td><?php echo $data['nama_obat']; ?></td>
            </tr>
        </table>
    </div>
    <script>
        window.print(); // Secara otomatis membuka jendela cetak saat halaman dimuat
    </script>
</body>
</html>
<?php
} else {
    echo "Data tidak ditemukan.";
}
?>
